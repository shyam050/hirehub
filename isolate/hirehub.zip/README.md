# HireHub

A full-stack campus recruitment platform where students find and apply for jobs, recruiters manage candidates, and admins oversee the entire placement process.

Built with **React**, **TypeScript**, **Tailwind CSS**, and **Convex** for the backend/database.

---

## Features

### Student
- Register and create a profile (education, skills, projects)
- Upload and manage PDF resumes
- Browse, search, and filter job positions
- Apply for jobs with a single click
- Track application status through a visual timeline
- View and manage upcoming interviews
- Receive notifications for status changes and interview updates

### Recruiter
- Register and create a company profile
- Post, edit, and close job positions
- Review and filter applicants
- Shortlist, reject, or advance candidates through stages
- Schedule, reschedule, cancel, and complete interviews
- Submit interview feedback
- Receive notifications for new applications

### Admin
- Manage students, recruiters, and companies
- Approve or reject company registrations
- View all jobs, applications, and platform statistics

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19, TypeScript, React Router |
| Styling | Tailwind CSS, shadcn/ui |
| Backend | Convex (serverless functions) |
| Auth | Convex Auth (email OTP) |
| Build Tool | Vite |

---

## Project Structure

```
├── convex/                    # Convex config
├── src/
│   ├── convex/                # Backend (schema, queries, mutations)
│   │   ├── schema.ts          # Database schema
│   │   ├── users.ts           # User management
│   │   ├── students.ts        # Student profile CRUD
│   │   ├── recruiters.ts      # Recruiter + company management
│   │   ├── jobs.ts            # Job CRUD, applications
│   │   ├── interviews.ts      # Interview scheduling & management
│   │   └── notifications.ts   # Notification system
│   ├── components/            # Shared UI components
│   │   ├── ui/                # shadcn/ui primitives
│   │   ├── dashboards/        # Role-specific dashboard views
│   │   ├── DashboardSidebar.tsx
│   │   ├── Notifications.tsx
│   │   ├── ThemeToggle.tsx
│   │   └── ScheduleInterviewDialog.tsx
│   ├── pages/                 # Route pages
│   │   ├── Landing.tsx
│   │   ├── Auth.tsx
│   │   ├── Dashboard.tsx
│   │   └── dashboard/         # Dashboard sub-pages
│   ├── lib/                   # Constants, utilities
│   ├── hooks/                 # Auth hooks
│   ├── main.tsx               # App entry + routing
│   └── index.css              # Theme tokens + styles
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## Prerequisites

- **Node.js** v18 or later
- **Bun** (recommended) or npm/yarn
- A **Convex** account (free tier works)

---

## Setup Instructions

### 1. Clone the project

```bash
git clone <your-repo-url>
cd hirehub
```

Or if you downloaded the ZIP:

```bash
unzip hirehub.zip
cd hirehub
```

### 2. Install dependencies

```bash
bun install
```

Or with npm:

```bash
npm install
```

### 3. Set up Convex

Initialize Convex and link it to your project:

```bash
bunx convex dev --once
```

This will:
- Ask you to log in to Convex (opens a browser window)
- Create a new Convex project if one doesn't exist
- Push the schema and generate TypeScript types

### 4. Configure environment variables

The Convex URL is automatically managed by Convex Auth. If you need to set it manually, create a `.env.local` file:

```
VITE_CONVEX_URL=<your-convex-deployment-url>
```

You can find this URL in your Convex dashboard or in the output of `bunx convex dev`.

### 5. Start the dev server

```bash
bun run dev
```

This starts both:
- The Vite dev server (frontend) at `http://localhost:5173`
- The Convex dev process (backend) that watches for changes

### 6. Open the app

Visit **http://localhost:5173** in your browser.

---

## First-Time Usage

1. **Sign up** with your email on the Auth page
2. **Enter the OTP** sent to your email
3. **Select your role** — Student or Recruiter
4. **Complete your profile**
5. Start using the platform!

> **Admin accounts** cannot be self-assigned. They must be created directly in the Convex database or through a separate admin provisioning process.

---

## Database Schema

The Convex schema defines these tables:

| Table | Purpose |
|-------|---------|
| `users` | Authentication and role management |
| `students` | Student profiles (education, skills, projects) |
| `recruiters` | Recruiter profiles linked to companies |
| `companies` | Company information and approval status |
| `jobs` | Job postings with requirements and metadata |
| `applications` | Job applications with status and timeline |
| `resumes` | PDF resume storage references |
| `interviews` | Interview scheduling, status, and feedback |
| `notifications` | In-app notification system |

---

## Application Flow

### Student
```
Register → Complete Profile → Upload Resume → Browse Jobs → Apply → Track Application → Interview → Feedback
```

### Recruiter
```
Register → Create Company → (Admin Approval) → Post Positions → Review Applicants → Schedule Interviews → Submit Feedback
```

### Application Stages
```
Applied → Screening → Shortlisted → Technical Interview → HR Interview → Offered → Selected / Rejected
```

Every status change is recorded in the application timeline.

---

## Authorization

Every Convex function enforces authorization server-side:

- **Students** can only access their own profile, resumes, applications, and interviews
- **Recruiters** can only manage their own company's jobs, applicants, and interviews
- **Admins** have read access to all platform data
- Role changes are restricted — users cannot self-assign admin roles

---

## License

This project is private and not licensed for public use.
